#include <pic18f4520.h>
#include <xc.h>
#define _XTAL_FREQ 4000000

void speak(void);
void buzzer_init(void);
