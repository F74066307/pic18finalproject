#include <pic18f4520.h>
#include <xc.h>

void PIN_MANAGER_Initialize(void);
