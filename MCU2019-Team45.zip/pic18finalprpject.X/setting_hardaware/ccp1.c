#include <xc.h>
#include "ccp1.h"

void CCP1_Initialize() {
    
}
