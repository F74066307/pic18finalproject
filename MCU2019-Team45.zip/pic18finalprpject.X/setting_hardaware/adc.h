#include <pic18f4520.h>
#include <xc.h>
#include <stdlib.h>
#include <math.h>
#define _XTAL_FREQ 4000000

void MQ_Read(double* values);
void ADC_Initialize(void);

